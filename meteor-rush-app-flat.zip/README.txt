METEOR RUSH - phone install (all files in one folder, no sub-folders)

Upload ALL of these files to a free web host (for example GitHub Pages),
open the link on your phone, then use "Install app" / "Add to Home Screen".
